import React from 'react'
import Portifolio from './Portifolio'
import { useNavigate } from 'react-router-dom'
import Style from './home.module.css'

const Home = () => {
  let navigate=useNavigate()
  let about=()=>{
    navigate("/about")
  }
  return (
    <>
     <Portifolio/>
     <section style={{height:"632px"}}>
     <img className={Style.img1} style={{borderRadius:"50%",marginLeft:"130px",marginTop:"130px"}} 
          src="../public/images/img2.jpg" height="350px" width="350px" alt="image" />
      <h1 style={{position:"absolute",top:"840px",left:"518px",fontSize:"35px"}}>About Me</h1>
      <h1 style={{position:"absolute",top:"900px",left:"518px",fontSize:"50px"}}>Frontend Developer</h1>
      <p style={{position:"absolute",top:"1020px",left:"650px",fontSize:"22px"}}>
      Hello I am Sushma Harshitha, a passionate and dedicated frontend developer with a <br />
       keen interest in creating dynamic, responsive, and visually appealing web applications. <br />
        I recently graduated with a degree in B.Tech from JNTUK, where I developed a <br />
         strong foundation in web development technologies and best practices.</p>
      <button onClick={about} style={{height:"45px",width:"160px",border:"3px solid",borderRadius:"10px",
        backgroundColor:"darkorange",color:"white",fontSize:"15px",marginLeft:"170px"}}>
          More About me...</button>
     </section>
     <section  style={{height:"632px",backgroundColor:"darkorange"}}>
      <h1 style={{fontSize:"30px",paddingLeft:"600px"}}>CONTACT ME</h1>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"50px"}}>
        <b>Email:</b> vsushmaharshitha02@gmail.com</p>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"10px"}}>
        <b>LinkedIn:</b>
        <a href="https://www.linkedin.com/in/v-sushma-harshitha-584079214/?originalSubdomain=in">
        https://www.linkedin.com/in/v-sushma-harshitha-584079214/?originalSubdomain=in</a></p>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"10px"}}>
        <b>GitHub:</b><a href="https://github.com/SushmaHarshitha">https://github.com/SushmaHarshitha</a></p>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"30px"}}>
        I am excited to start my career in frontend development and look forward to contributing 
        to innovative and impactful projects.
        <br /> Feel free to reach out to me for collaboration or any opportunities!</p>
     </section>
    </>
  )
}

export default Home