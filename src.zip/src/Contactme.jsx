import React from 'react'
import Navbar from './Navbar'

const Contactme = () => {

  return (
    <>
     <Navbar/>
     <section  style={{height:"632px"}}>
      <h1 style={{fontSize:"30px",paddingLeft:"600px"}}>CONTACT ME</h1>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"50px"}}>
        <b>Email:</b> vsushmaharshitha02@gmail.com</p>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"10px"}}>
        <b>LinkedIn: </b> 
        <a href="https://www.linkedin.com/in/v-sushma-harshitha-584079214/?originalSubdomain=in">
        https://www.linkedin.com/in/v-sushma-harshitha-584079214/?originalSubdomain=in</a></p>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"10px"}}>
        <b>GitHub:</b><a href="https://github.com/SushmaHarshitha">https://github.com/SushmaHarshitha</a> </p>

      <p style={{fontSize:"20px",paddingLeft:"100px",paddingTop:"30px"}}>
        I'm excited to start my career in frontend development and look forward to contributing to innovative and impactful projects.
        <br /> Feel free to reach out to me for collaboration or any opportunities!</p>
     </section>
    </>
  )
}

export default Contactme
