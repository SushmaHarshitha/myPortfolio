import React from 'react'
import Navbar from './Navbar'
import Style from "./skills.module.css"

const Skills = () => {
  return (
    <>
     <Navbar/> 
     <section className={Style.section}>
     <h1>FRONTEND</h1><br />
     <ul className={Style.ul}>
      <li>HTML</li>
      <li>CSS</li>
      <li>JS</li>
      <li>REACT JS</li>
     </ul>
     <h1>BACKEND</h1><br />
     <ul className={Style.ul}>
      <li>CORE JAVA</li>
      <li>Spring Boot</li>
     </ul>
     <h1>DATABASE</h1> <br />
     <ul className={Style.ul}>
      <li>SQL</li>
     </ul>
     </section>
    </>
  )
}

export default Skills
